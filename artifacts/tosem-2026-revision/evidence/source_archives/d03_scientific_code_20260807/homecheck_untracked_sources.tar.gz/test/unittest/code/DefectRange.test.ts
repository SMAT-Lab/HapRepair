/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { FullPosition } from 'arkanalyzer';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { describe, expect, test } from 'vitest';
import { Defects } from '../../../src/model/Defects';
import { DefectRangeUtils } from '../../../src/utils/common/DefectRangeUtils';
import { GeneratingJsonFile } from '../../../src/utils/common/GeneratingJsonFile';

const ARGS = [7, 3, 9, 'description', 1, '@test/rule', '/tmp/file.ets', 'docs/test.md',
    true, false, false] as const;

describe('DefectRange', () => {
    test('legacy defects retain fix identity and expose a legacy single-line range', () => {
        const defect = new Defects(...ARGS);

        expect(defect.fixKey).toBe('7%3%9%@test/rule');
        expect(defect.rangeStartLine).toBe(7);
        expect(defect.rangeStartColumn).toBe(3);
        expect(defect.endLine).toBe(7);
        expect(defect.endColumn).toBe(9);
        expect(defect.rangeSource).toBe('legacy');
    });

    test('native ranges serialize without changing the legacy fix identity', () => {
        const defect = new Defects(...ARGS, true, {
            startLine: 5,
            startColumn: 2,
            endLine: 11,
            endColumn: 6,
            source: 'ast-node',
        });
        const serialized = JSON.parse(JSON.stringify(defect));

        expect(defect.fixKey).toBe('7%3%9%@test/rule');
        expect(serialized.rangeStartLine).toBe(5);
        expect(serialized.rangeStartColumn).toBe(2);
        expect(serialized.endLine).toBe(11);
        expect(serialized.endColumn).toBe(6);
        expect(serialized.rangeSource).toBe('ast-node');
    });

    test('standalone JSON reports preserve native range fields', () => {
        const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'homecheck-range-'));
        const output = path.join(temp, 'issuesReport.json');
        try {
            const defect = new Defects(...ARGS, true, {
                startLine: 5,
                startColumn: 2,
                endLine: 11,
                endColumn: 6,
                source: 'ast-node',
            });
            GeneratingJsonFile.generatingJsonFile(output, [{
                filePath: '/tmp/file.ets',
                defects: [defect],
            }]);

            const report = JSON.parse(fs.readFileSync(output, 'utf8'));
            expect(report[0].messages[0]).toMatchObject({
                line: 7,
                column: 3,
                rangeStartLine: 5,
                rangeStartColumn: 2,
                endLine: 11,
                endColumn: 6,
                rangeSource: 'ast-node',
            });
        } finally {
            fs.rmSync(temp, { recursive: true, force: true });
        }
    });
});

describe('DefectRangeUtils', () => {
    test('computes exclusive single-line and CRLF multiline ends', () => {
        expect(DefectRangeUtils.fromText(4, 5, 'List()', 'declaration')).toEqual({
            startLine: 4,
            startColumn: 5,
            endLine: 4,
            endColumn: 11,
            source: 'declaration',
        });
        expect(DefectRangeUtils.fromText(4, 5, 'List() {\r\n  Text()\r\n}', 'declaration')).toEqual({
            startLine: 4,
            startColumn: 5,
            endLine: 6,
            endColumn: 2,
            source: 'declaration',
        });
    });

    test('copies a valid FullPosition and rejects invalid positions', () => {
        expect(DefectRangeUtils.fromFullPosition(
            new FullPosition(2, 4, 5, 8), 'ast-node')).toEqual({
            startLine: 2,
            startColumn: 4,
            endLine: 5,
            endColumn: 8,
            source: 'ast-node',
        });
        expect(DefectRangeUtils.fromFullPosition(FullPosition.DEFAULT, 'ast-node')).toBeUndefined();
        expect(DefectRangeUtils.fromFullPosition(
            new FullPosition(2, 4, 2, 4), 'ast-node')).toBeUndefined();
        expect(DefectRangeUtils.fromText(0, 1, 'text', 'declaration')).toBeUndefined();
        expect(DefectRangeUtils.fromText(1, 1, '', 'declaration')).toBeUndefined();
    });
});
