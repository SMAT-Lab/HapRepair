/*
 * Copyright (c) 2026 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { FullPosition, Stmt } from 'arkanalyzer';
import { DefectRange } from '../../model/Defects';

export class DefectRangeUtils {
    static fromFullPosition(position: FullPosition, source: DefectRange['source']): DefectRange | undefined {
        const firstLine = position.getFirstLine();
        const firstColumn = position.getFirstCol();
        const endLine = position.getLastLine();
        const endColumn = position.getLastCol();
        if (firstLine < 1 || firstColumn < 1 || endLine < firstLine || endColumn < 1 ||
            (endLine === firstLine && endColumn <= firstColumn)) {
            return undefined;
        }
        return { startLine: firstLine, startColumn: firstColumn, endLine, endColumn, source };
    }

    static fromText(startLine: number, startColumn: number, text: string,
        source: DefectRange['source']): DefectRange | undefined {
        if (startLine < 1 || startColumn < 1 || text.length === 0) {
            return undefined;
        }
        const lines = text.split(/\r?\n/);
        const endLine = startLine + lines.length - 1;
        const endColumn = lines.length === 1 ? startColumn + lines[0].length : lines[lines.length - 1].length + 1;
        return { startLine, startColumn, endLine, endColumn, source };
    }

    static fromStmt(stmt: Stmt): DefectRange | undefined {
        const position = stmt.getOriginPositionInfo();
        const text = stmt.getOriginalText();
        if (!text) {
            return undefined;
        }
        return this.fromText(position.getLineNo(), position.getColNo(), text, 'ir-statement');
    }
}
